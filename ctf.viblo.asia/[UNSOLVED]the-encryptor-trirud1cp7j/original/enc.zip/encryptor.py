from base64 import b64encode as b
from random import randint as r
from random import choice as c
from string import ascii_letters as x
from string import digits as y

f = '?????????????????????????????'  # Flag{some leet text}


def z(f):
    o = r(1, len(x + y))
    return f.translate(str.maketrans((x + y), (x + y)[o:] + (x + y)[:o]))


for i in range(50):
    f = b(f.encode('utf8')).decode('utf8') if c([0, 1]) else z(f)

open('encrypted.txt', 'w').write(f)
